package homework.calc.decorator;

import homework.calc.dataType.Formula;

public class RemainsDecor extends Decorator {

    public RemainsDecor(Formula src) {
        super(src);
    }

    @Override
    protected void replaceElements() {

    }
}
